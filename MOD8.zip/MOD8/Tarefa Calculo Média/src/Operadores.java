public class Operadores {
    public static void main(String[] args) {
        int num1 = 10;
        int num2 = 20;
        int num3 = 30;
        int num4 = 40;

        int num5 = (num1+num2+num3+num4)/4;

        System.out.println(num5);

    }
}

